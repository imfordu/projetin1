document.addEventListener("DOMContentLoaded", () => {
  const elementos = document.querySelectorAll(".animar-entrada");

  elementos.forEach((el, index) => {
    el.style.opacity = "0";
    el.style.transform = `translateX(${index % 2 === 0 ? '-100px' : '100px'})`;
    el.style.transition = "all 0.8s ease-out";
  });

  setTimeout(() => {
    elementos.forEach((el) => {
      el.style.opacity = "1";
      el.style.transform = "translateX(0)";
    });
  }, 100); // tempo para a transição começar após carregamento
});
// Efeitos.js (opcional para extensões futuras)
// Exemplo: iniciar animações após o DOM estar pronto
document.addEventListener("DOMContentLoaded", () => {
  // Futuras animações dinâmicas podem vir aqui
});
